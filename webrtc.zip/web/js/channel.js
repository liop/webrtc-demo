/*
* @Author: lizhengfeng
* @Date:   2017-11-15 14:51:15
* @Last Modified by:   lizhengfeng
* @Last Modified time: 2017-11-15 15:02:33
*/

var dataChannelSend = document.getElementById('dataChannelSend');
var dataChannelReceive = document.getElementById('dataChannelReceive');

var startBtn = document.getElementById('startBtn');
var sendButton = document.getElementById('sendButton');
var closeButton = document.getElementById('closeButton');

var dataChannel = null;
if (window.pc === undefined) {
  pc = null;
}

startBtn.onclick = function () {
  if (!pc) {
    start();
  }
}
sendButton